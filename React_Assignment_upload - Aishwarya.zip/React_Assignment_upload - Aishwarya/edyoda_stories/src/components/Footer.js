import React from "react";
import "./Footer.css";
const Footer = () => {
  return (
    <footer>
      <div>EdYoda Developer Programs</div>
      <div >Page created by Aishwarya </div>
    </footer>
  );
};

export default Footer;
